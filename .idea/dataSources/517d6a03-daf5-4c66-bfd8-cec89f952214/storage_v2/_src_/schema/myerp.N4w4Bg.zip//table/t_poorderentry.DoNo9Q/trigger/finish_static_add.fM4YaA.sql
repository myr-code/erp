create definer = root@localhost trigger finish_static_add
    before update
    on t_poorderentry
    for each row
BEGIN

if NEW.finish_qty>=NEW.qty then

 set NEW.finish_static = 1;
 
 ELSE
 
 set NEW.finish_static = 0;
 
end if;


end;

