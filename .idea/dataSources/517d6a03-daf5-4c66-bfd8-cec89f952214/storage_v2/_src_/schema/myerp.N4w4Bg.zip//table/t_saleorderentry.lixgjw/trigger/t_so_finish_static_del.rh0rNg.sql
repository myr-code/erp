create definer = root@localhost trigger t_so_finish_static_del
    after delete
    on t_saleorderentry
    for each row
BEGIN


#t_saleorderentry所有行都完成 则 主表t_saleorder 为 1
if (select case when sum(finish_static) = max(entryId) then 1 else 0 end from t_saleorderentry where mid = OLD.mid) = 1 then

 update t_saleorder set finish_static = 1 where fid = OLD.mid;
 
 ELSE
 
 update t_saleorder set finish_static = 0 where fid = OLD.mid;
 
end if;


end;

