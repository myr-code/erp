create
    definer = root@localhost function GetBillNo(ruleid int, dates varchar(20)) returns varchar(30)
BEGIN
	#Routine body goes here...
#set @temp = 1;#规则id
#set @prefix = '';#前缀 SO
#set @subject = '';#主体 YYYYMMDD
#set @digit = 0;#顺延位数
#set @nohead = '';#当前需要匹配的格式头
#set @nowmaxbillno = '';#匹配后当前最大的单据号
#set @returnmaxbillno = '';#自增后的最大单号


set @prefix=(SELECT dePrefix from t_billrule where fid = ruleid);
set @subjects=(SELECT deSubject from t_billrule where fid = ruleid);
set @digit=(SELECT deDigit from t_billrule where fid = ruleid);

set @nohead =(select CONCAT(@prefix,GetDateFormat(dates,@subjects)) );

if ruleid = 1 then
	set @nowmaxbillno =(select MAX(billNo) from t_saleorder where left(billNo,LENGTH(@nohead)) = @nohead and LENGTH(billNo) = LENGTH(@nohead)+@digit);
ELSEIF ruleid = 2 then
	set @nowmaxbillno =(select MAX(billNo) from t_poorder where left(billNo,LENGTH(@nohead)) = @nohead and LENGTH(billNo) = LENGTH(@nohead)+@digit);
ELSEIF ruleid = 3 then
	set @nowmaxbillno =(select MAX(billNo) from icstockbill where left(billNo,LENGTH(@nohead)) = @nohead and LENGTH(billNo) = LENGTH(@nohead)+@digit);
ELSEIF ruleid = 4 then
set @nowmaxbillno =(select MAX(billNo) from t_bom where left(billNo,LENGTH(@nohead)) = @nohead and LENGTH(billNo) = LENGTH(@nohead)+@digit);
ELSE
	set @nowmaxbillno ='';
end if;


set @returnmaxbillno =(select IFNULL(CONCAT(@prefix,RIGHT(@nowmaxbillno,LENGTH(@subjects)+@digit)+1),CONCAT(@nohead,RIGHT(POW(10,@digit+1)+1,@digit))) );




	RETURN @returnmaxbillno;
END;

