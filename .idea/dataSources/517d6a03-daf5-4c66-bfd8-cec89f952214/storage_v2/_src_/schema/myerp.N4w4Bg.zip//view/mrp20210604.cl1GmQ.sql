create view mrp20210604 as
select `a`.`itemId` AS `itemId`, `a`.`cuid` AS `cuid`, sum(`a`.`demand_qty`) AS `sum(demand_qty)`
from (select `a`.`itemId` AS `itemId`, `b`.`cuid` AS `cuid`, (`a`.`qty` * `b`.`qty`) AS `demand_qty`
      from (`myerp`.`icstockbillentry` `a`
               left join `myerp`.`v_bom_all_cuid` `b` on ((`a`.`itemId` = `b`.`topid`)))
      where ((`a`.`mid` = 12) and (`b`.`topid` > 0))
      union all
      select `a`.`itemId` AS `itemId`, `a`.`itemId` AS `itemId`, `a`.`qty` AS `qty`
      from (`myerp`.`icstockbillentry` `a`
               left join `myerp`.`v_bom_all_cuid` `b` on ((`a`.`itemId` = `b`.`topid`)))
      where ((`a`.`mid` = 12) and isnull(`b`.`topid`))) `a`
group by `a`.`itemId`, `a`.`cuid`;

