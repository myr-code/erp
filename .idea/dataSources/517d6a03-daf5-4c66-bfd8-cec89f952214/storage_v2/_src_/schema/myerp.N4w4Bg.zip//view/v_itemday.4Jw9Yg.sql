create definer = root@localhost view v_itemday as
select `a`.`billDate`                                                                   AS `billDate`,
       `a`.`billType`                                                                   AS `billType`,
       `b`.`stockId`                                                                    AS `stockId`,
       `b`.`itemId`                                                                     AS `itemId`,
       (case when (`a`.`billType` = '销售出库') then (`b`.`qty` * -(1)) else `b`.`qty` end) AS `qty`,
       `b`.`taxPrice`                                                                   AS `taxPrice`
from ((`myerp`.`icstockbill` `a` join `myerp`.`icstockbillentry` `b` on ((`a`.`fid` = `b`.`mid`)))
         join `myerp`.`t_item` `c` on (((`b`.`itemId` = `c`.`fid`) and (`c`.`isstock` = 0))));

