create definer = root@localhost view v_bom_grade as
select `a`.`muid`                                            AS `muid`,
       `a`.`itemCode`                                        AS `itemCode`,
       `a`.`itemName`                                        AS `itemName`,
       `a`.`itemModel`                                       AS `itemModel`,
       `a`.`custItemCode`                                    AS `custItemCode`,
       `a`.`qty`                                             AS `qty`,
       `a`.`unitName`                                        AS `unitName`,
       `b`.`cuid`                                            AS `cuid`,
       `b`.`itemCode`                                        AS `citemCode`,
       `b`.`itemName`                                        AS `citemName`,
       `b`.`itemModel`                                       AS `citemModel`,
       `b`.`custItemCode`                                    AS `ccustItemCode`,
       `b`.`qty`                                             AS `cqty`,
       `b`.`unitName`                                        AS `cunitName`,
       (case when (`c`.`qty` > 0) then `c`.`qty` else 0 end) AS `nextmqty`
from ((`myerp`.`t_bom` `a` join `myerp`.`t_bomentry` `b` on ((`a`.`fid` = `b`.`mid`)))
         left join `myerp`.`t_bom` `c` on ((`b`.`cuid` = `c`.`muid`)))
order by `a`.`muid`, `b`.`entryId`;

