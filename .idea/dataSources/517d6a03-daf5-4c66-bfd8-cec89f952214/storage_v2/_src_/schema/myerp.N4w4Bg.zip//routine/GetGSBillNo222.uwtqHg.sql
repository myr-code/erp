create
    definer = root@localhost function GetGSBillNo222(ruleid int, dates varchar(20)) returns varchar(30)
BEGIN
	#Routine body goes here...
#set @temp = 1;#规则id
#set @prefix = '';#前缀 SO
#set @subject = '';#主体 YYYYMMDD
#set @digit = 0;#顺延位数
#set @nohead = '';#当前需要匹配的格式头
#set @nowmaxbillno = '';#匹配后当前最大的单据号
#set @returnmaxbillno = '';#自增后的最大单号

#SELECT GetDateFormat('2032-12-31','YYYYMM')

set @prefix=(SELECT case when isdiy = 1 then custPrefix else dePrefix end from t_billrule where fid = ruleid);
set @subjects=(SELECT case when isdiy = 1 then custSubject else deSubject end from t_billrule where fid = ruleid);
set @digit=(SELECT case when isdiy = 1 then custDigit else deDigit end from t_billrule where fid = ruleid);


set @nohead =(select CONCAT(@prefix,GetDateFormat(dates,@subjects)) );

set @nowmaxbillno =(select MAX(GSBillNo) from t_saleorder where left(GSBillNo,LENGTH(@nohead)) = @nohead and LENGTH(GSBillNo) = LENGTH(@nohead)+@digit);

set @returnmaxbillno =(select IFNULL(CONCAT(@prefix,RIGHT(@nowmaxbillno,LENGTH(@subjects)+@digit)+1),CONCAT(@nohead,RIGHT(POW(10,@digit+1)+1,@digit))) );




	RETURN @returnmaxbillno;
END;

