create definer = root@localhost view v_dateformat2 as
select 'YYYYMMDD' AS `format`, concat(`a`.`YYYY`, `a`.`MM`, `a`.`DD`) AS `value`
from `myerp`.`v_dateformat` `a`
union all
select 'YYMMDD' AS `YYMMDD`, concat(`a`.`YY`, `a`.`MM`, `a`.`DD`) AS `concat(``a``.``YY``,``a``.``MM``,``a``.``DD``)`
from `myerp`.`v_dateformat` `a`
union all
select 'YYYYMM' AS `YYYYMM`, concat(`a`.`YYYY`, `a`.`MM`) AS `concat(``a``.``YYYY``,``a``.``MM``)`
from `myerp`.`v_dateformat` `a`
union all
select 'YYMM' AS `YYMM`, concat(`a`.`YY`, `a`.`MM`) AS `concat(``a``.``YY``,``a``.``MM``)`
from `myerp`.`v_dateformat` `a`
union all
select 'MMDD' AS `MMDD`, concat(`a`.`MM`, `a`.`DD`) AS `concat(``a``.``MM``,``a``.``DD``)`
from `myerp`.`v_dateformat` `a`
union all
select 'YYYY' AS `YYYY`, `a`.`YYYY` AS `YYYY`
from `myerp`.`v_dateformat` `a`
union all
select 'MM' AS `MM`, `a`.`MM` AS `mm`
from `myerp`.`v_dateformat` `a`
union all
select 'DD' AS `DD`, `a`.`DD` AS `dd`
from `myerp`.`v_dateformat` `a`;

