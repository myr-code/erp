create definer = root@localhost view v_bom_all_cuid as
select `a`.`dj` AS `dj`, `a`.`topid` AS `topid`, `a`.`muid` AS `muid`, `a`.`cuid` AS `cuid`, `a`.`qty` AS `qty`
from (select 1                                                                    AS `dj`,
             `myerp`.`t_bomentry`.`muid`                                          AS `topid`,
             `myerp`.`t_bomentry`.`muid`                                          AS `muid`,
             `myerp`.`t_bomentry`.`cuid`                                          AS `cuid`,
             round((`myerp`.`t_bomentry`.`qty` / `myerp`.`t_bomentry`.`mqty`), 4) AS `qty`
      from `myerp`.`t_bomentry`
      union all
      select 2                                                               AS `层级`,
             `a`.`muid`                                                      AS `muid`,
             `b`.`muid`                                                      AS `muid`,
             `b`.`cuid`                                                      AS `cuid`,
             round((((`a`.`qty` / `a`.`mqty`) * `b`.`qty`) / `b`.`mqty`), 4) AS `a.qty*b.qty`
      from (`myerp`.`t_bomentry` `a`
               left join `myerp`.`t_bomentry` `b` on ((`a`.`cuid` = `b`.`muid`)))
      where (`b`.`muid` > 0)
      union all
      select 3                                                                                            AS `层级`,
             `a`.`muid`                                                                                   AS `muid`,
             `c`.`muid`                                                                                   AS `muid`,
             `c`.`cuid`                                                                                   AS `cuid`,
             round((((((`a`.`qty` / `a`.`mqty`) * `b`.`qty`) / `b`.`mqty`) * `c`.`qty`) / `c`.`mqty`),
                   4)                                                                                     AS `a.qty*b.qty*c.qty`
      from ((`myerp`.`t_bomentry` `a` left join `myerp`.`t_bomentry` `b` on ((`a`.`cuid` = `b`.`muid`)))
               left join `myerp`.`t_bomentry` `c` on ((`b`.`cuid` = `c`.`muid`)))
      where (`c`.`muid` > 0)
      union all
      select 4                      AS `层级`,
             `a`.`muid`             AS `muid`,
             `d`.`muid`             AS `muid`,
             `d`.`cuid`             AS `cuid`,
             round((((((((`a`.`qty` / `a`.`mqty`) * `b`.`qty`) / `b`.`mqty`) * `c`.`qty`) / `c`.`mqty`) * `d`.`qty`) /
                    `d`.`mqty`), 4) AS `a.qty*b.qty*c.qty*d.qty`
      from (((`myerp`.`t_bomentry` `a` left join `myerp`.`t_bomentry` `b` on ((`a`.`cuid` = `b`.`muid`))) left join `myerp`.`t_bomentry` `c` on ((`b`.`cuid` = `c`.`muid`)))
               left join `myerp`.`t_bomentry` `d` on ((`c`.`cuid` = `d`.`muid`)))
      where (`d`.`muid` > 0)
      union all
      select 5                                                   AS `层级`,
             `a`.`muid`                                          AS `muid`,
             `e`.`muid`                                          AS `muid`,
             `e`.`cuid`                                          AS `cuid`,
             round((((((((((`a`.`qty` / `a`.`mqty`) * `b`.`qty`) / `b`.`mqty`) * `c`.`qty`) / `c`.`mqty`) * `d`.`qty`) /
                      `d`.`mqty`) * `e`.`qty`) / `e`.`mqty`), 4) AS `a.qty*b.qty*c.qty*d.qty*e.qty`
      from ((((`myerp`.`t_bomentry` `a` left join `myerp`.`t_bomentry` `b` on ((`a`.`cuid` = `b`.`muid`))) left join `myerp`.`t_bomentry` `c` on ((`b`.`cuid` = `c`.`muid`))) left join `myerp`.`t_bomentry` `d` on ((`c`.`cuid` = `d`.`muid`)))
               left join `myerp`.`t_bomentry` `e` on ((`d`.`cuid` = `e`.`muid`)))
      where (`e`.`muid` > 0)) `a`
order by `a`.`topid`, `a`.`dj`;

