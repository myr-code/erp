create view v_itemstock_bystock as
select `a`.`itemId`        AS `itemId`,
       `a`.`stockId`       AS `stockId`,
       sum(`a`.`qty`)      AS `qty`,
       avg(`a`.`taxprice`) AS `taxprice`
from (select `v_itemday`.`itemId`        AS `itemId`,
             `v_itemday`.`stockId`       AS `stockId`,
             sum(`v_itemday`.`qty`)      AS `qty`,
             avg(`v_itemday`.`taxPrice`) AS `taxprice`
      from `myerp`.`v_itemday`
      where (year(`v_itemday`.`billDate`) >
             ifnull((select max(`myerp`.`e_itemyear`.`year`) from `myerp`.`e_itemyear`), '2020'))
      group by `v_itemday`.`itemId`, `v_itemday`.`stockId`
      union all
      select `myerp`.`e_itemyear`.`itemid`     AS `itemid`,
             `myerp`.`e_itemyear`.`stockId`    AS `stockId`,
             sum(`myerp`.`e_itemyear`.`qty`)   AS `qty`,
             avg(`myerp`.`e_itemyear`.`price`) AS `price`
      from `myerp`.`e_itemyear`
      where (`myerp`.`e_itemyear`.`year` =
             ifnull((select max(`myerp`.`e_itemyear`.`year`) from `myerp`.`e_itemyear`), '2020'))
      group by `myerp`.`e_itemyear`.`itemid`, `myerp`.`e_itemyear`.`stockId`) `a`
group by `a`.`itemId`, `a`.`stockId`;

