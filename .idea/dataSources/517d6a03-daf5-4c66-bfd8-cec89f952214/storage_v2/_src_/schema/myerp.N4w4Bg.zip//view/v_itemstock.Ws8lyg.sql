create definer = root@localhost view v_itemstock as
select `a`.`itemId` AS `itemId`, sum(`a`.`qty`) AS `qty`, avg(`a`.`taxprice`) AS `taxprice`
from (select `v_itemday`.`itemId`        AS `itemId`,
             sum(`v_itemday`.`qty`)      AS `qty`,
             avg(`v_itemday`.`taxPrice`) AS `taxprice`
      from `myerp`.`v_itemday`
      where (year(`v_itemday`.`billDate`) >
             ifnull((select max(`myerp`.`e_itemyear`.`year`) from `myerp`.`e_itemyear`), '2020'))
      group by `v_itemday`.`itemId`
      union all
      select `myerp`.`e_itemyear`.`itemid`     AS `itemid`,
             sum(`myerp`.`e_itemyear`.`qty`)   AS `qty`,
             avg(`myerp`.`e_itemyear`.`price`) AS `price`
      from `myerp`.`e_itemyear`
      where (`myerp`.`e_itemyear`.`year` =
             ifnull((select max(`myerp`.`e_itemyear`.`year`) from `myerp`.`e_itemyear`), '2020'))
      group by `myerp`.`e_itemyear`.`itemid`) `a`
group by `a`.`itemId`;

