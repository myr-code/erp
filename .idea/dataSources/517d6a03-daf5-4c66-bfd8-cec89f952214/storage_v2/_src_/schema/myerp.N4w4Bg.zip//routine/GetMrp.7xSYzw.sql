create
    definer = root@localhost procedure GetMrp(IN mrp_ids varchar(50), IN demand_qty_type int, IN isoneplane int)
BEGIN
	#Routine body goes here...
	#mrp_ids:mrp_calc_temp表中的id
	#qty_type:1按需求生成采购单、其他按综合需求生成采购单
	#isoneplane:1一款成品一张备料 其他合成一张

#生成mrp生产单号
set @billNo_productplan = GetBillNo(7,DATE_FORMAT(NOW(),'%Y-%m-%d'));

#1、新增采购申请单
#生成单号
set @billNo_pur_req = GetBillNo(5,DATE_FORMAT(NOW(),'%Y-%m-%d'));

SET @i = 0;#自增行号
if demand_qty_type = 1 then 

insert into mrp_pur_req(billNo,billDate,mrpNo,entryId,finishDate,itemId,qty,taxPrice,taxPriceNo,
taxAmt,taxAmtNo,remark,sourFid,createDate)
select @billNo_pur_req,now(),@billNo_productplan,(@i:=@i+1),date_add(now(),interval 3 day),child_item_id,demand_qty ,b.purPrice,b.purPrice,
demand_qty*b.purPrice,demand_qty*b.purPrice,'MRP计算自动生成',sos_fid,now() 
from mrp_calc_temp a left join t_item b on a.child_item_id = b.fid
where mrp_id = mrp_ids;

else

insert into mrp_pur_req(billNo,billDate,mrpNo,entryId,finishDate,itemId,qty,taxPrice,taxPriceNo,
taxAmt,taxAmtNo,remark,sourFid,createDate)
select @billNo_pur_req,now(),@billNo_productplan,(@i:=@i+1),date_add(now(),interval 3 day),child_item_id,demand_zh_qty ,b.purPrice,b.purPrice,
demand_zh_qty*b.purPrice,demand_zh_qty*b.purPrice,'MRP计算自动生成',sos_fid,now() 
from mrp_calc_temp a left join t_item b on a.child_item_id = b.fid
where mrp_id = mrp_ids and demand_zh_qty >0;

end if;
#添加单号
insert into mrp_bill_list(mrp_id,bill_type,billNo) VALUES (mrp_ids,1,@billNo_pur_req);


#2、新增张备料、计划单
if isoneplane = 1 then


#自增行号
SET @m = 0;
drop table if EXISTS ls_dissos;
#不重复订单子表
CREATE TEMPORARY TABLE IF NOT EXISTS ls_dissos 
select (@m:=@m+1) as rows,sos_fid from (select distinct sos_fid as 'sos_fid' from mrp_calc_temp where mrp_id = mrp_ids) a;
#成品数量
set @sossum = (select count(distinct sos_fid) from mrp_calc_temp where mrp_id = mrp_ids);
SET @n = 0;

		WHILE @n<@sossum DO # 结束循环的条件: 当i大于5时跳出while循环
			
			#2.1一款成品一张备料、计划单
			#生成单号
			set @billNo_backmater2 = GetBillNo(6,DATE_FORMAT(NOW(),'%Y-%m-%d'));
			#获取客户id
			set @custId_backmater2 = (
			select case when count(DISTINCT a.custId) =1 then a.custId else -1 end  from t_saleorder a 
			left join t_saleorderentry b on a.fid = b.mid
			left join mrp_calc_temp c on b.fid = c.sos_fid 
			where mrp_id = mrp_ids and sos_fid = (select sos_fid from ls_dissos where rows = @n+1) 
			);
			#生成mrp生产单号
			set @billNo_productplan2 = GetBillNo(7,DATE_FORMAT(NOW(),'%Y-%m-%d'));
			#自增行号
			SET @b = 0;

			#新增
			insert into mrp_backmater(billNo,billDate,custId,mrpNo,entryId,finishDate,itemId,stand_qty,
			qty,taxPrice,taxPriceNo,taxAmt,taxAmtNo,remark,sourFid,createDate)
			select @billNo_backmater2,now(),@custId_backmater2,@billNo_productplan2,(@b:=@b+1),date_add(now(),interval 3 day),child_item_id,
			case when c.qty>0 then c.qty else 1 end as 'stand_qty',
			demand_qty ,b.purPrice,b.purPrice,
			demand_qty*b.purPrice,demand_qty*b.purPrice,'MRP计算自动生成',sos_fid,now() 
			from mrp_calc_temp a left join t_item b on a.child_item_id = b.fid
			left join v_bom_all_cuid c on a.main_item_id = c.muid and a.child_item_id = c.cuid
			where mrp_id = mrp_ids and sos_fid = (select sos_fid from ls_dissos where rows = @n+1);
			
			#3、新增生产计划单
			SET @k = 0;#自增行号
			insert into mrp_productplan(billNo,billDate,custId,entryId,finishDate,itemId,qty,taxPrice,
			taxPriceNo,taxAmt,taxAmtNo,remark,sourFid,createDate)
			select @billNo_productplan2,now(),@custId_backmater2,(@k:=@k+1),date_add(now(),interval 3 day),c.itemId,c.qty ,b.purPrice,
			b.purPrice,c.qty*b.purPrice,c.qty*b.purPrice,'MRP计算自动生成',sos_fid,now() 
			from mrp_calc_temp a left join t_item b on a.child_item_id = b.fid
			left JOIN t_saleorderentry c on a.sos_fid = c.fid
			where mrp_id = mrp_ids and sos_fid = (select sos_fid from ls_dissos where rows = @n+1);

			#添加单号 备料单
			insert into mrp_bill_list(mrp_id,bill_type,billNo) VALUES (mrp_ids,2,@billNo_backmater2);
			#添加单号 计划单
			insert into mrp_bill_list(mrp_id,bill_type,billNo) VALUES (mrp_ids,3,@billNo_productplan2);

			set @n = @n+1;
		END WHILE;


else

#2.2多款款成品一张备料、计划单
#生成单号
set @billNo_backmater = GetBillNo(6,DATE_FORMAT(NOW(),'%Y-%m-%d'));
#自增行号
SET @j = 0;
#获取客户id
set @custId_backmater = (
select case when count(DISTINCT a.custId) =1 then a.custId else -1 end  from t_saleorder a left join t_saleorderentry b on a.fid = b.mid
left join mrp_calc_temp c on b.fid = c.sos_fid where mrp_id = mrp_ids
);

#新增
insert into mrp_backmater(billNo,billDate,custId,mrpNo,entryId,finishDate,itemId,stand_qty,
qty,taxPrice,taxPriceNo,taxAmt,taxAmtNo,remark,sourFid,createDate)
select @billNo_backmater,now(),@custId_backmater,@billNo_productplan,(@j:=@j+1),date_add(now(),interval 3 day),child_item_id,
case when c.qty>0 then c.qty else 1 end as 'stand_qty',
demand_qty ,b.purPrice,b.purPrice,
demand_qty*b.purPrice,demand_qty*b.purPrice,'MRP计算自动生成',sos_fid,now() 
from mrp_calc_temp a left join t_item b on a.child_item_id = b.fid
left join v_bom_all_cuid c on a.main_item_id = c.muid and a.child_item_id = c.cuid
where mrp_id = mrp_ids;

#3、新增生产计划单
SET @k = 0;#自增行号
insert into mrp_productplan(billNo,billDate,custId,entryId,finishDate,itemId,qty,taxPrice,
taxPriceNo,taxAmt,taxAmtNo,remark,sourFid,createDate)
select @billNo_productplan,now(),@custId_backmater,(@k:=@k+1),date_add(now(),interval 3 day),c.itemId,c.qty ,b.purPrice,
b.purPrice,c.qty*b.purPrice,c.qty*b.purPrice,'MRP计算自动生成',sos_fid,now() 
from mrp_calc_temp a left join t_item b on a.child_item_id = b.fid
left JOIN t_saleorderentry c on a.sos_fid = c.fid
where mrp_id = mrp_ids;


#添加单号 备料单
insert into mrp_bill_list(mrp_id,bill_type,billNo) VALUES (mrp_ids,2,@billNo_backmater);
#添加单号 计划单
insert into mrp_bill_list(mrp_id,bill_type,billNo) VALUES (mrp_ids,3,@billNo_productplan);

end if;

#返回单号列表
select bill_type as 'itemId',billNo as 'mainItemCode' from mrp_bill_list where mrp_id = mrp_ids order by bill_type,billNo;



END;

