create definer = root@localhost trigger soentry_ismrp_up
    after update
    on mrp_productplan
    for each row
BEGIN

if NEW.sourFid>0 and (select case when count(*) then 1 else 0 end from t_saleorderentry where fid = NEW.sourFid)>0 then

 update t_saleorderentry set ismrp = 1  where fid = NEW.sourFid;
 
end if;


end;

