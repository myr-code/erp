create definer = root@localhost trigger backmater_finish_qty_add
    after insert
    on mrp_productpick
    for each row
BEGIN

if NEW.sourType = '生产备料单' then

 update mrp_backmater 
 set finish_qty = (select sum(qty) from mrp_productpick where sourBillNo = NEW.sourBillNo and sourEntryId = NEW.sourEntryId) 
 where billNo = NEW.sourBillNo and entryId = NEW.sourEntryId and itemId = NEW.itemId;
 
 #更新状态
 update mrp_backmater 
 set finish_static = (case when finish_qty>=qty then 1 else 0 end) 
 where billNo = NEW.sourBillNo and entryId = NEW.sourEntryId and itemId = NEW.itemId;
 
 end if;
 
 END;

