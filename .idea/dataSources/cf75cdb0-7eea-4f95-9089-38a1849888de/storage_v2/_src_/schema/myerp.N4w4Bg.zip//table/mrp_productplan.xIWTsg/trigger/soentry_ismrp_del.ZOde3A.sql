create definer = root@localhost trigger soentry_ismrp_del
    after delete
    on mrp_productplan
    for each row
BEGIN

if OLD.sourFid>0 and (select case when count(*) then 1 else 0 end from t_saleorderentry where fid = OLD.sourFid)>0 then

 update t_saleorderentry set ismrp = 0  where fid = OLD.sourFid;
 
end if;


end;

