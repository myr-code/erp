create definer = root@localhost trigger finish_qty_return_add
    after insert
    on icstockbillentry
    for each row
BEGIN

if NEW.sourType = '采购订单' then

 update t_poorderentry 
 set finish_qty = (select sum(qty) from icstockbillentry where sourFid = NEW.sourFid and sourEntryId = NEW.sourEntryId) 
 where mid = NEW.sourFid and entryId = NEW.sourEntryId;
 
ELSEIF NEW.sourType = '销售订单' then
 
 update t_saleorderentry 
 set finish_qty = (select sum(qty) from icstockbillentry where sourFid = NEW.sourFid and sourEntryId = NEW.sourEntryId) 
 where mid = NEW.sourFid and entryId = NEW.sourEntryId;
 
 end if;
 
 END;

