create definer = root@localhost trigger soentry_finish_static_up
    before update
    on t_saleorderentry
    for each row
BEGIN

if NEW.finish_qty>=NEW.qty then

 set NEW.finish_static = 1;
 
 ELSE
 
 set NEW.finish_static = 0;
 
end if;


end;

