create definer = root@localhost trigger pur_req_finish_qty_add
    after insert
    on t_poorderentry
    for each row
BEGIN

if NEW.sourType = '采购申请单' then

 update mrp_pur_req 
 set finish_qty = (select sum(qty) from t_poorderentry where sourBillNo = NEW.sourBillNo and sourEntryId = NEW.sourEntryId) 
 where billNo = NEW.sourBillNo and entryId = NEW.sourEntryId;
 
 end if;
 
 END;

