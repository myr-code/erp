create definer = root@localhost view v_dateformat as
select cast(curdate() as date)               AS `YYYY-MM-DD`,
       year(curdate())                       AS `YYYY`,
       substr(cast(curdate() as date), 3, 2) AS `YY`,
       substr(cast(curdate() as date), 6, 2) AS `MM`,
       substr(cast(curdate() as date), 9, 2) AS `DD`;

