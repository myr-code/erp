create definer = root@localhost trigger prodplan_finish_qty_up
    after update
    on mrp_productinstore
    for each row
BEGIN

if OLD.sourType = '生产计划单' then

 update mrp_productplan 
 set finish_qty = (select sum(qty) from mrp_productinstore where sourBillNo = OLD.sourBillNo and sourEntryId = OLD.sourEntryId) 
 where billNo = OLD.sourBillNo and entryId = OLD.sourEntryId and itemId = OLD.itemId;
 
   #更新状态
 update mrp_productplan 
 set finish_static = (case when finish_qty>=qty then 1 else 0 end) 
 where billNo = OLD.sourBillNo and entryId = OLD.sourEntryId and itemId = OLD.itemId;
 
 end if;
 
 END;

