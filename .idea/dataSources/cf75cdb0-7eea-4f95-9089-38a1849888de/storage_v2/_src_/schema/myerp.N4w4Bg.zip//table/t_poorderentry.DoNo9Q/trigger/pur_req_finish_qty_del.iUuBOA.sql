create definer = root@localhost trigger pur_req_finish_qty_del
    after delete
    on t_poorderentry
    for each row
BEGIN

if OLD.sourType = '采购申请单' then

 update mrp_pur_req 
 set finish_qty = (select sum(qty) from t_poorderentry where sourBillNo = OLD.sourBillNo and sourEntryId = OLD.sourEntryId) 
 where billNo = OLD.sourBillNo and entryId = OLD.sourEntryId;
 
 end if;
 
 END;

