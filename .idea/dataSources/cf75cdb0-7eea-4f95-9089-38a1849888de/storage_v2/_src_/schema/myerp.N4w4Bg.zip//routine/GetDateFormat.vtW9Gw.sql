create
    definer = root@localhost function GetDateFormat(dates varchar(10), format varchar(30)) returns varchar(30)
BEGIN
	#Routine body goes here...


set @YYYY = (select year(dates));
set @YY = (select substr(cast(dates as date),3,2));
set @MM = (select substr(cast(dates as date),6,2));
set @DD = (select substr(cast(dates as date),9,2));

set @dateformat = (
select `value` from 
(select 'YYYYMMDD' AS `formats`,concat(@YYYY,@MM,@DD) AS `value`
union all 
select 'YYMMDD' AS `YYMMDD`,concat(@YY,@MM,@MM) 
union all
select 'YYYYMM' AS `YYYYMM`,concat(@YYYY,@MM) 
union all
select 'YYMM' AS `YYMM`,concat(@YY,@MM) 
union all
select 'MMDD' AS `MMDD`,concat(@MM,@DD)
union all
select 'YYYY' AS `YYYY`,@YYYY
union all
select 'MM' AS `MM`,@MM 
union all 
select 'DD' AS `DD`,@DD ) ls where formats = format
);


#例：GetDateFormat('2021-03-04','YYYYMM')  202103
	RETURN @dateformat;
END;

