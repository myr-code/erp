create definer = root@localhost trigger prodplan_finish_qty_add
    after insert
    on mrp_productinstore
    for each row
BEGIN

if NEW.sourType = '生产计划单' then

 update mrp_productplan 
 set finish_qty = (select sum(qty) from mrp_productinstore where sourBillNo = NEW.sourBillNo and sourEntryId = NEW.sourEntryId) 
 where billNo = NEW.sourBillNo and entryId = NEW.sourEntryId and itemId = NEW.itemId;
 
  #更新状态
 update mrp_productplan 
 set finish_static = (case when finish_qty>=qty then 1 else 0 end) 
 where billNo = NEW.sourBillNo and entryId = NEW.sourEntryId and itemId = NEW.itemId;
 
 end if;
 
 END;

