create definer = root@localhost trigger pur_req_add_finish_static
    before insert
    on mrp_pur_req
    for each row
BEGIN

if NEW.finish_qty>=NEW.qty then

 set NEW.finish_static = 1;
 
 ELSE
 
 set NEW.finish_static = 0;
 
end if;


end;

