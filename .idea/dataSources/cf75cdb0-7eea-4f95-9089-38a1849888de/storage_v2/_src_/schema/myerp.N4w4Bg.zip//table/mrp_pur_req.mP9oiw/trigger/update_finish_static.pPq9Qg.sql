create definer = root@localhost trigger update_finish_static
    before update
    on mrp_pur_req
    for each row
BEGIN

if NEW.finish_qty>=NEW.qty then

 set NEW.finish_static = 1;
 
 ELSE
 
 set NEW.finish_static = 0;
 
end if;


end;

