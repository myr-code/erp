create definer = root@localhost trigger finish_qty_return_del
    after delete
    on icstockbillentry
    for each row
BEGIN

if OLD.sourType = '采购订单' then
 update t_poorderentry 
 set finish_qty = (select sum(qty) from icstockbillentry where sourFid = OLD.sourFid and sourEntryId = OLD.sourEntryId) 
 where mid = OLD.sourFid and entryId = OLD.sourEntryId;
 
ELSEIF OLD.sourType = '销售订单' then
 
 update t_saleorderentry 
 set finish_qty = (select sum(qty) from icstockbillentry where sourFid = OLD.sourFid and sourEntryId = OLD.sourEntryId) 
 where mid = OLD.sourFid and entryId = OLD.sourEntryId;
 
 end if;
 
 END;

