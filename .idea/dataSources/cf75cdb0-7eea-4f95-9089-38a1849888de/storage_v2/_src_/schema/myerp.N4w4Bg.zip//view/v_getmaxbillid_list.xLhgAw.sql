create definer = root@localhost view v_getmaxbillid_list as
select max(`myerp`.`t_saleorder`.`billNo`) AS `billNo`, `myerp`.`t_saleorder`.`billDate` AS `billDate`
from `myerp`.`t_saleorder`
group by `myerp`.`t_saleorder`.`billDate`;

