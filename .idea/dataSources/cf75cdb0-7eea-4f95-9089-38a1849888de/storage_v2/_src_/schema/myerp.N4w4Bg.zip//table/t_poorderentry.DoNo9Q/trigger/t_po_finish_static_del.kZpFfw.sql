create definer = root@localhost trigger t_po_finish_static_del
    after delete
    on t_poorderentry
    for each row
BEGIN

#t_poorderentry所有行都完成 则 主表t_poorder 为 1
if (select case when sum(finish_static) = max(entryId) then 1 else 0 end from t_poorderentry where mid = OLD.mid) = 1 then

 update t_poorder set finish_static = 1 where fid = OLD.mid;
 
 ELSE
 
 update t_poorder set finish_static = 0 where fid = OLD.mid;
 
end if;


end;

