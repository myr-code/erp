create definer = root@localhost view v_itemday as
select `a`.`billDate`                AS `billDate`,
       `a`.`billType`                AS `billType`,
       `b`.`stockId`                 AS `stockId`,
       `b`.`itemId`                  AS `itemId`,
       (`b`.`qty` * `b`.`stockType`) AS `qty`,
       `b`.`taxPrice`                AS `taxPrice`
from ((`myerp`.`icstockbill` `a` join `myerp`.`icstockbillentry` `b` on ((`a`.`fid` = `b`.`mid`)))
         join `myerp`.`t_item` `c` on (((`b`.`itemId` = `c`.`fid`) and (`c`.`isstock` = 0))))
union all
select `p`.`billDate`     AS `billDate`,
       '生产领料'             AS `生产领料`,
       `p`.`stockId`      AS `stockId`,
       `p`.`itemId`       AS `itemId`,
       (`p`.`qty` * -(1)) AS `qty*-1`,
       `p`.`taxPrice`     AS `taxPrice`
from (`myerp`.`mrp_productpick` `p`
         left join `myerp`.`t_item` `t` on (((`p`.`itemId` = `t`.`fid`) and (`t`.`isstock` = 0))))
union all
select `p`.`billDate` AS `billDate`,
       '成品入库'         AS `成品入库`,
       `p`.`stockId`  AS `stockId`,
       `p`.`itemId`   AS `itemId`,
       `p`.`qty`      AS `qty`,
       `p`.`taxPrice` AS `taxPrice`
from (`myerp`.`mrp_productinstore` `p`
         left join `myerp`.`t_item` `t` on (((`p`.`itemId` = `t`.`fid`) and (`t`.`isstock` = 0))));

